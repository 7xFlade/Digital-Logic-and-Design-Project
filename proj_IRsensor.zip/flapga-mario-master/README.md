# FlaPGA Mario

This is a flappy-bird like video game written in Verilog for Basys 3. This project was also submitted as a school project in my freshmen year. The report is available here: [FlaPGA_Mario.pdf](https://howardlau.me/wp-content/uploads/2018/11/FlapPGA_Mario.pdf)

中文博客介绍：[FlapPGA Mario - 用 FPGA 编写游戏](https://howardlau.me/projects/flappga-mario-a-video-game-in-fpga.html)

# Demo

You can watch the demo here: [https://www.youtube.com/watch?v=SdphC7bAz7M](https://www.youtube.com/watch?v=SdphC7bAz7M)

